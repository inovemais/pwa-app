module.exports= {
    'Admin': 'admin',
    'Member': 'member',
    'NonMember': 'notMember',
    'Anonimous': 'anonimous',
}